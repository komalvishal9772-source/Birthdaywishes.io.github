
// Copy wish text to clipboard
document.getElementById('shareBtn').addEventListener('click', function(){
  const text = 'Happy Birthday Tannu! Wishing you a day filled with love, laughter and cake. ❤️';
  navigator.clipboard.writeText(text).then(function(){
    alert('Wish copied to clipboard — paste to share!');
  }, function(){
    alert('Could not copy. Please select and copy manually:' + '\n' + text);
  });
});

// Download the card as an image (basic approach using SVG serialization)
document.getElementById('downloadCard').addEventListener('click', function(e){
  e.preventDefault();
  // Serialize the card area (simple method — captures SVG cake and surrounding text as an SVG)
  const card = document.querySelector('.card');
  const clone = card.cloneNode(true);
  // Inline styles to improve rendering
  clone.style.boxShadow = 'none';
  const svgBlob = new Blob(['<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800"><foreignObject width="100%" height="100%">' + new XMLSerializer().serializeToString(clone) + '</foreignObject></svg>'], {type: 'image/svg+xml'});
  const url = URL.createObjectURL(svgBlob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'tannu-birthday-card.svg';
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
});
